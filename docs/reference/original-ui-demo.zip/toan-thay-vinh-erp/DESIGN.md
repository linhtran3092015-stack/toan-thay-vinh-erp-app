# Toán Thầy Vinh ERP — Style Reference
> Hệ thống quản trị giáo dục hiện đại: chuyên nghiệp, sáng sủa, dữ liệu dày mà không rối.

**Theme:** Light (default) · Dark mode: không dùng làm mặc định

Giao diện Toán Thầy Vinh đặt nền trắng tinh làm canvas chính, tạo cảm giác sạch sẽ và đáng tin cậy — đúng như kỳ vọng của một hệ thống tài chính giáo dục. Sidebar navy đậm (`#24348B`) cố định bên trái hoạt động như neo thị giác, mang lại sự ổn định khi người dùng điều hướng giữa hàng chục module nghiệp vụ. Typeface **Be Vietnam Pro** được chọn bởi khả năng hỗ trợ tiếng Việt xuất sắc cùng tính cách semi-humanist rõ ràng — không quá cứng nhắc như font kỹ thuật, không quá mềm mại như font tiêu dùng. Màu nhấn secondary blue (`#4F72FF`) được dùng tiết chế để chỉ xuất hiện tại các điểm tương tác quan trọng (link, active state, CTA phụ), trong khi màu trạng thái (xanh lá, đỏ, vàng, tím) mang theo ngữ nghĩa rõ ràng — không dùng chỉ để trang trí. Card hệ thống dùng bóng đổ rất nhẹ và viền `#E6EAF2` mỏng, tạo độ sâu mà không nặng nề. Signature của thiết kế này là dữ liệu KPI hiển thị số lớn bold bên cạnh sparkline mảnh — sự tương phản này cung cấp thông tin ngay lập tức mà không cần người dùng đọc chi tiết.

---

## Tokens — Colors

### Brand & Primary

| Name | Value | Token | Role |
|------|-------|-------|------|
| Navy Primary | `#24348B` | `--color-primary` | Sidebar bg, menu active, nút CTA chính |
| Navy Hover | `#1D2A73` | `--color-primary-hover` | Trạng thái hover của primary |
| Primary Soft | `#EEF1FF` | `--color-primary-soft` | Background nhẹ cho icon, highlight |
| Secondary Blue | `#4F72FF` | `--color-secondary` | Link, active indicator, accent |
| Accent Purple | `#7C5CFC` | `--color-accent-purple` | Badge học thử, coaching, đặc biệt |
| Accent Teal | `#2FB8A6` | `--color-accent-teal` | Biểu đồ, chỉ số tích cực thứ yếu |

### Semantic States

| Name | Value | Token | Role |
|------|-------|-------|------|
| Success | `#22A06B` | `--color-success` | Trạng thái "Đang học", thanh toán OK |
| Success Background | `#EAF8F1` | `--color-success-bg` | Badge bg cho trạng thái tốt |
| Warning | `#E58A16` | `--color-warning` | Cảnh báo vắng, sắp hết buổi |
| Warning Background | `#FFF5E5` | `--color-warning-bg` | Badge bg cho cảnh báo |
| Danger | `#D6455D` | `--color-danger` | Âm buổi, lỗi, thao tác nguy hiểm |
| Danger Background | `#FFF0F3` | `--color-danger-bg` | Badge bg cho nguy hiểm |
| Info | `#3478F6` | `--color-info` | Thông báo thông tin, trạng thái chờ |
| Info Background | `#EDF4FF` | `--color-info-bg` | Badge bg cho thông tin |
| Neutral | `#64748B` | `--color-neutral` | Trạng thái trung lập, không hoạt động |
| Neutral Background | `#F4F6F8` | `--color-neutral-bg` | Badge bg trung lập |

### Neutral & Surface

| Name | Value | Token | Role |
|------|-------|-------|------|
| App Background | `#F6F8FC` | `--color-canvas` | Nền toàn trang |
| Card Background | `#FFFFFF` | `--color-surface-1` | Card, panel, topbar |
| Elevated | `#FAFBFD` | `--color-surface-2` | Drawer, dropdown |
| Border | `#E6EAF2` | `--color-hairline` | Viền card, input, separator |
| Border Focus | `#4F72FF` | `--color-hairline-focus` | Viền khi focus input |
| Primary Text | `#17203A` | `--color-ink` | Heading, body text chính |
| Secondary Text | `#667085` | `--color-ink-muted` | Text phụ, label, placeholder hint |
| Muted Text | `#98A2B3` | `--color-ink-subtle` | Metadata, timestamp, disabled |
| Disabled Background | `#F2F4F7` | `--color-disabled-bg` | Trạng thái disabled |
| Sidebar Text | `#FFFFFF` | `--color-sidebar-ink` | Text/icon trên sidebar navy |
| Sidebar Muted | `rgba(255,255,255,0.55)` | `--color-sidebar-muted` | Text phụ trên sidebar |
| Sidebar Hover | `rgba(255,255,255,0.10)` | `--color-sidebar-hover` | Hover state trên sidebar |
| Sidebar Active | `rgba(255,255,255,0.18)` | `--color-sidebar-active` | Active menu item bg |

### Chart Colors

| Name | Value | Token | Role |
|------|-------|-------|------|
| Chart Blue | `#4F72FF` | `--color-chart-1` | Bar/line chart chính (doanh thu) |
| Chart Teal | `#2FB8A6` | `--color-chart-2` | Đường số giao dịch |
| Chart Purple | `#7C5CFC` | `--color-chart-3` | Segment donut (lớp 6) |
| Chart Orange | `#F59E0B` | `--color-chart-4` | Segment donut (lớp 9) |
| Chart Pink | `#EC4899` | `--color-chart-5` | Segment donut (lớp 10) |
| Chart Green | `#22A06B` | `--color-chart-6` | Segment MMA |
| Chart Indigo | `#6366F1` | `--color-chart-7` | Segment Sandbox |

---

## Tokens — Typography

### Be Vietnam Pro — Semi-humanist, đa dụng, tối ưu tiếng Việt · `--font-body`
- **Substitute:** Inter, Nunito Sans
- **Weights:** 400 (regular), 500 (medium), 600 (semibold), 700 (bold)
- **Sizes:** 12px, 13px, 14px, 16px, 18px, 20px, 24px, 26px, 28px, 32px, 34px
- **Line height:** 1.4–1.6 cho body; 1.1–1.2 cho số KPI
- **Letter spacing:** 0 cho body; -0.02em cho heading lớn; tnum cho số tiền
- **OpenType features:** `tnum` (tabular numerals) bắt buộc cho cột số tiền
- **Role:** Font duy nhất cho toàn bộ hệ thống

### Type Scale

| Role | Size | Weight | Line Height | Letter Spacing | Token |
|------|------|--------|-------------|----------------|-------|
| KPI Number | 32–34px | 700 | 1.1 | -0.02em | `--text-kpi` |
| Page Title | 24–28px | 600 | 1.2 | -0.01em | `--text-page-title` |
| Section Title | 18–20px | 600 | 1.3 | 0 | `--text-section` |
| Card Title | 14–16px | 500 | 1.4 | 0 | `--text-card-title` |
| Body | 14px | 400 | 1.5 | 0 | `--text-body` |
| Body Small | 13px | 400 | 1.5 | 0 | `--text-body-sm` |
| Caption / Meta | 12px | 400 | 1.4 | 0 | `--text-caption` |

---

## Tokens — Spacing & Shapes

**Density:** Comfortable · **Base unit:** 4px

### Spacing Scale

| Name | Value | Token |
|------|-------|-------|
| xxs | 4px | `--spacing-1` |
| xs | 8px | `--spacing-2` |
| sm | 12px | `--spacing-3` |
| md | 16px | `--spacing-4` |
| lg | 20px | `--spacing-5` |
| xl | 24px | `--spacing-6` |
| 2xl | 32px | `--spacing-8` |
| 3xl | 40px | `--spacing-10` |
| 4xl | 48px | `--spacing-12` |
| 5xl | 64px | `--spacing-16` |

### Border Radius

| Name | Value | Token |
|------|-------|-------|
| xs | 4px | `--radius-xs` |
| sm | 6px | `--radius-sm` |
| md | 8px | `--radius-md` |
| lg | 12px | `--radius-lg` |
| xl | 16px | `--radius-xl` |
| pill | 9999px | `--radius-pill` |

| Element | Radius |
|---------|--------|
| Button / Input | 8px |
| Card | 12–16px |
| Modal | 16px |
| Badge | pill (9999px) |
| Avatar | pill |

### Shadows

| Name | Value | Token |
|------|-------|-------|
| card | `0 1px 3px rgba(23,32,58,0.06), 0 1px 2px rgba(23,32,58,0.04)` | `--shadow-card` |
| card-hover | `0 4px 12px rgba(23,32,58,0.10), 0 2px 4px rgba(23,32,58,0.06)` | `--shadow-card-hover` |
| dropdown | `0 8px 24px rgba(23,32,58,0.12), 0 2px 8px rgba(23,32,58,0.06)` | `--shadow-dropdown` |
| modal | `0 20px 60px rgba(23,32,58,0.18), 0 4px 16px rgba(23,32,58,0.08)` | `--shadow-modal` |
| drawer | `0 0 40px rgba(23,32,58,0.14)` | `--shadow-drawer` |
| focus-ring | `0 0 0 3px rgba(79,114,255,0.25)` | `--shadow-focus` |

### Layout

- **Sidebar width:** 240px (desktop) · 64px (collapsed)
- **Topbar height:** 64px
- **Content max-width:** 1600px
- **Card padding:** 20–24px
- **Section gap:** 24px

---

## Components

### KPI Card
**Role:** Hiển thị số liệu tóm tắt (học viên, doanh thu, công nợ)

- background: `--color-surface-1` (#FFFFFF)
- border: `1px solid --color-hairline` (#E6EAF2)
- border-radius: `--radius-lg` (12px)
- padding: 20px 24px
- box-shadow: `--shadow-card`
- Icon container: 40×40px, border-radius pill, background semantic-soft color
- KPI number: 32px / 700 / `--color-ink`
- Label: 14px / 500 / `--color-ink-muted`
- Delta tăng: 12px / 500 / `--color-success` + arrow-up icon
- Delta giảm: 12px / 500 / `--color-danger` + arrow-down icon
- Sparkline: 56×28px, line 1.5px, fill opacity 0.08

### Primary Button
**Role:** Hành động chính trên mỗi màn hình

- background: `--color-primary` (#24348B)
- color: #FFFFFF
- border-radius: 8px; height: 40px (md), 32px (sm), 44px (lg)
- padding: 10px 20px; font: 14px / 600
- hover: background `--color-primary-hover` (#1D2A73)
- disabled: background `--color-disabled-bg`, color `--color-ink-subtle`

### Secondary Button
**Role:** Hành động phụ, import, export

- background: #FFFFFF; border: `1px solid --color-hairline`
- color: `--color-ink`; border-radius: 8px; padding: 10px 20px
- hover: background `#F6F8FC`, border-color `--color-secondary`

### Status Badge
**Role:** Trạng thái học viên, giao dịch, nghiệp vụ

- border-radius: pill; padding: 3px 10px; font: 12px / 500

| Trạng thái | Text Color | Background |
|------------|------------|------------|
| Đang học | `#22A06B` | `#EAF8F1` |
| Bảo lưu | `#E58A16` | `#FFF5E5` |
| Chờ xác nhận | `#3478F6` | `#EDF4FF` |
| Âm buổi | `#D6455D` | `#FFF0F3` |
| Học thử | `#7C5CFC` | `#F3F0FF` |
| Đã khóa | `#64748B` | `#F4F6F8` |
| Cảnh báo | `#D6455D` | `#FFF0F3` |
| Chờ duyệt | `#E58A16` | `#FFF5E5` |
| Hoàn thành | `#22A06B` | `#EAF8F1` |
| Cần coaching | `#7C5CFC` | `#F3F0FF` |

### Input Field
**Role:** Thu thập dữ liệu trong form

- background: #FFFFFF; border: `1px solid --color-hairline`; border-radius: 8px
- padding: 10px 12px; font: 14px / 400; height: 40px
- focus: border-color `--color-secondary`, box-shadow `--shadow-focus`
- error: border-color `--color-danger`
- disabled: background `--color-disabled-bg`
- Label: 13px / 500 / `--color-ink-muted`, margin-bottom 6px

### Data Table
**Role:** Danh sách dữ liệu nghiệp vụ

- Header: background `#F6F8FC`, font 12px / 600 / `--color-ink-muted`, height 40px
- Row: height 52px (comfortable), border-bottom `1px solid --color-hairline`
- Row hover: background `#F8FAFF`
- Number cell: tabular-nums, text-align right
- Sticky first column: box-shadow right `2px 0 4px rgba(0,0,0,0.04)`

### Sidebar Navigation
**Role:** Điều hướng toàn hệ thống

- background: `--color-primary` (#24348B); width: 240px
- Item: height 44px, padding 10px 16px, border-radius 10px
- font: 14px / 500 / #FFFFFF; icon: 20px Lucide line
- hover: background `rgba(255,255,255,0.10)`
- active: background `rgba(255,255,255,0.18)`, font-weight 600

### Topbar
**Role:** Tìm kiếm, thông báo, user menu

- background: #FFFFFF; height: 64px
- border-bottom: `1px solid --color-hairline`
- Search: width 320px, shortcut badge `⌘K`

### Drawer
**Role:** Xem chi tiết bên phải không rời màn hình danh sách

- width: 480px; background: #FFFFFF; box-shadow: `--shadow-drawer`
- animation: slide-in-right 200ms ease-out

### Modal
**Role:** Xác nhận, thao tác ngắn

- width: 480px (sm), 640px (md); background: #FFFFFF
- border-radius: 16px; box-shadow: `--shadow-modal`
- Overlay: rgba(23,32,58,0.40)

---

## Surfaces

| Level | Name | Value | Purpose |
|-------|------|-------|---------|
| 0 | canvas | `#F6F8FC` | Nền toàn trang |
| 1 | surface-1 | `#FFFFFF` | Card, topbar, sidebar |
| 2 | surface-2 | `#FAFBFD` | Drawer, dropdown, elevated panel |
| 3 | surface-3 | `#F4F6F8` | Table header, input disabled |

---

## Do's and Don'ts

### Do
- Dùng `--color-primary` (#24348B) chỉ cho sidebar, button CTA chính và menu active.
- Dùng tabular numerals (`font-variant-numeric: tabular-nums`) cho mọi cột số tiền và số buổi.
- Dùng badge trạng thái semantic color để người dùng nhận biết không cần đọc text.
- Dùng skeleton loading cho card và table thay vì spinner toàn trang.
- Giữ sidebar 240px trên desktop — icon-only làm mất label ảnh hưởng tốc độ điều hướng.
- Dùng `--shadow-card` thay vì border đậm — bóng nhẹ + viền `--color-hairline` là signature.
- Hiển thị số dư buổi màu đỏ khi âm, vàng khi ≤ 3 buổi.
- Dùng drawer bên phải cho xem chi tiết, không mở trang mới.

### Don't
- Đừng dùng gradient hoặc glassmorphism làm nền card chính.
- Đừng dùng màu nền đậm toàn bộ cho card KPI.
- Đừng dùng quá 3 màu biểu đồ trên một chart.
- Đừng đặt font size dưới 12px.
- Đừng dùng modal chồng modal — dùng drawer hoặc full-page form thay thế.
- Đừng dùng màu là tín hiệu DUY NHẤT — luôn kết hợp icon hoặc text.
- Đừng để bảng thiếu sticky header và pagination.
- Đừng xóa dữ liệu nghiệp vụ — dùng "Vô hiệu hóa", "Hủy", "Điều chỉnh".

---

## Layout

Bố cục **fixed sidebar + fixed topbar + scrollable content area**. Sidebar 240px, topbar 64px, content area max-width 1600px, padding 24px. Dashboard dùng grid 12 cột, gutter 16px. Dòng KPI chia 5 cột đều; khối biểu đồ tỉ lệ 7:5. Tablet thu sidebar về icon-only. Mobile dùng bottom navigation hoặc drawer trái.

---

## Quick Start

### CSS Custom Properties

```css
@import url('https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700&display=swap');

:root {
  /* Brand Colors */
  --color-primary: #24348B;
  --color-primary-hover: #1D2A73;
  --color-primary-soft: #EEF1FF;
  --color-secondary: #4F72FF;
  --color-accent-purple: #7C5CFC;
  --color-accent-teal: #2FB8A6;

  /* Semantic States */
  --color-success: #22A06B;
  --color-success-bg: #EAF8F1;
  --color-warning: #E58A16;
  --color-warning-bg: #FFF5E5;
  --color-danger: #D6455D;
  --color-danger-bg: #FFF0F3;
  --color-info: #3478F6;
  --color-info-bg: #EDF4FF;
  --color-neutral: #64748B;
  --color-neutral-bg: #F4F6F8;

  /* Surfaces & Text */
  --color-canvas: #F6F8FC;
  --color-surface-1: #FFFFFF;
  --color-surface-2: #FAFBFD;
  --color-hairline: #E6EAF2;
  --color-hairline-focus: #4F72FF;
  --color-ink: #17203A;
  --color-ink-muted: #667085;
  --color-ink-subtle: #98A2B3;
  --color-disabled-bg: #F2F4F7;

  /* Typography */
  --font-body: 'Be Vietnam Pro', Inter, -apple-system, sans-serif;
  --text-kpi: 32px;
  --text-page-title: 26px;
  --text-section: 18px;
  --text-card-title: 15px;
  --text-body: 14px;
  --text-body-sm: 13px;
  --text-caption: 12px;

  /* Spacing */
  --spacing-1: 4px;  --spacing-2: 8px;   --spacing-3: 12px;
  --spacing-4: 16px; --spacing-5: 20px;  --spacing-6: 24px;
  --spacing-8: 32px; --spacing-10: 40px; --spacing-12: 48px;

  /* Border Radius */
  --radius-xs: 4px; --radius-sm: 6px;  --radius-md: 8px;
  --radius-lg: 12px; --radius-xl: 16px; --radius-pill: 9999px;

  /* Shadows */
  --shadow-card: 0 1px 3px rgba(23,32,58,0.06), 0 1px 2px rgba(23,32,58,0.04);
  --shadow-card-hover: 0 4px 12px rgba(23,32,58,0.10), 0 2px 4px rgba(23,32,58,0.06);
  --shadow-dropdown: 0 8px 24px rgba(23,32,58,0.12), 0 2px 8px rgba(23,32,58,0.06);
  --shadow-modal: 0 20px 60px rgba(23,32,58,0.18), 0 4px 16px rgba(23,32,58,0.08);
  --shadow-drawer: 0 0 40px rgba(23,32,58,0.14);
  --shadow-focus: 0 0 0 3px rgba(79,114,255,0.25);

  /* Layout */
  --sidebar-width: 240px;
  --topbar-height: 64px;
  --content-max-width: 1600px;
  --card-padding: 24px;
}
```

### Tailwind v4

```css
@theme {
  --color-primary: #24348B;
  --color-primary-hover: #1D2A73;
  --color-primary-soft: #EEF1FF;
  --color-secondary: #4F72FF;
  --color-accent-purple: #7C5CFC;
  --color-accent-teal: #2FB8A6;
  --color-success: #22A06B;
  --color-success-bg: #EAF8F1;
  --color-warning: #E58A16;
  --color-warning-bg: #FFF5E5;
  --color-danger: #D6455D;
  --color-danger-bg: #FFF0F3;
  --color-info: #3478F6;
  --color-info-bg: #EDF4FF;
  --color-canvas: #F6F8FC;
  --color-surface-1: #FFFFFF;
  --color-hairline: #E6EAF2;
  --color-ink: #17203A;
  --color-ink-muted: #667085;
  --color-ink-subtle: #98A2B3;
  --font-body: 'Be Vietnam Pro', Inter, -apple-system, sans-serif;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-xl: 16px;
  --radius-pill: 9999px;
  --shadow-card: 0 1px 3px rgba(23,32,58,0.06), 0 1px 2px rgba(23,32,58,0.04);
  --shadow-modal: 0 20px 60px rgba(23,32,58,0.18), 0 4px 16px rgba(23,32,58,0.08);
}
```
