# 🏫 Toán Thầy Vinh ERP — UI Source Code & Backend Contract

Bộ mã nguồn giao diện hoàn chỉnh (30/30 màn hình) của **Hệ thống ERP Quản lý Trung tâm Toán Thầy Vinh**, sẵn sàng để bắt đầu phát triển **Backend / Database / REST API**.

---

## 📁 Cấu trúc Thư mục

```
toan-thay-vinh-erp/
├── README.md                      # Tài liệu hướng dẫn & Tích hợp Backend API
├── DESIGN.md                      # Spec hệ thống thiết kế (Design Tokens)
├── package.json                   # Cấu hình dự án
├── public/
│   ├── index.html                 # Bản giao diện tương tác 30/30 màn hình
│   ├── preview.html               # Visualizer các Token thiết kế (Color, Font, Component)
│   └── styles/
│       └── variables.css          # CSS Variables chuẩn hóa theo design spec
└── src/
    ├── types/
    │   └── index.ts               # TypeScript API Data Models
    └── api/
        └── index.ts               # Danh sách Endpoint REST API Backend
```

---

## 🚀 Hướng dẫn Chạy Giao diện

1. **Xem trực tiếp**: Double click file `public/index.html` để mở trong trình duyệt.
2. **Chạy Local Server**:
   ```bash
   cd toan-thay-vinh-erp
   npm start
   ```
   Ứng dụng sẽ chạy tại `http://localhost:3000`

---

## ⚙️ Hướng dẫn Tích hợp Backend

Đội ngũ phát triển Backend sử dụng contract định nghĩa tại:
- `src/types/index.ts`: Các Schema / Data Interfaces chính (Học viên, Lớp học, Điểm danh, SePay, CRM, Lương, Phân quyền).
- `src/api/index.ts`: Các REST API routes cần xây dựng.

*Được chốt thiết kế và tạo thành công theo đúng spec `design(2).md`.*
