/**
 * TOÁN THẦY VINH ERP - TYPESAFE API CONTRACT DEFINITIONS
 */

export type Grade = "Lớp 6" | "Lớp 7" | "Lớp 8" | "Lớp 9" | "Lớp 10";
export type ClassLevel = "A" | "B" | "CLC";
export type LearningMode = "Online" | "Offline";
export type LeadSource = "MMA" | "Sandbox" | "Fanpage" | "Giới thiệu" | "Khác";
export type StudentStatus = "Đang học" | "Bảo lưu" | "Chờ xác nhận" | "Đã nghỉ";

export interface Student {
  id: string; // e.g. "TV-2026-00125"
  fullName: string;
  nickname?: string;
  birthYear: number;
  gender: "Nam" | "Nữ";
  grade: Grade;
  classId: string;
  className: string;
  mode: LearningMode;
  source: LeadSource;
  level: ClassLevel;
  balanceSessions: number;
  monthlyFee: number;
  status: StudentStatus;
  parentId: string;
  parentName: string;
  parentPhone: string;
}

export interface Parent {
  id: string;
  fullName: string;
  phone: string;
  children: Student[];
  totalBalanceSessions: number;
  totalFeePaid: number;
}

export interface ClassItem {
  id: string;
  name: string;
  grade: Grade;
  level: ClassLevel;
  mode: LearningMode;
  fixedSchedule: string;
  activeStudentsCount: number;
  maxCapacity: number;
}

export interface SessionRecord {
  id: string;
  classId: string;
  className: string;
  sessionNumber: number;
  date: string;
  timeSlot: string;
  presentCount: number;
  totalStudents: number;
  isLocked: boolean;
}

export interface PaymentRequest {
  id: string;
  studentId: string;
  studentName: string;
  type: "Tái phí" | "Tuyển mới";
  amount: number;
  transferContent: string;
  status: "Chờ TT" | "Đã TT" | "Đã hủy";
}

export interface SePayTransaction {
  id: string;
  timestamp: string;
  amount: number;
  content: string;
  suggestedStudentName?: string;
  status: "Đã hoàn tất" | "Chưa xác định" | "Chờ xác nhận";
}

export interface Lead {
  id: string;
  parentName: string;
  phone: string;
  childName: string;
  grade: Grade;
  stage: string;
  saleAssignedName: string;
  isOverdue: boolean;
}
