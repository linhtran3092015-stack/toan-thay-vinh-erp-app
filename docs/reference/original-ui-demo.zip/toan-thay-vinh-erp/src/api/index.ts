/**
 * TOÁN THẦY VINH ERP - REST API ENDPOINT SPECIFICATIONS FOR BACKEND DEVELOPERS
 */

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN_GOOGLE: "/api/v1/auth/google",
    ME: "/api/v1/auth/me",
  },
  STUDENTS: {
    LIST: "/api/v1/students",
    DETAIL: (id: string) => `/api/v1/students/${id}`,
    CREATE: "/api/v1/students",
  },
  CLASSES: {
    LIST: "/api/v1/classes",
    DETAIL: (id: string) => `/api/v1/classes/${id}`,
  },
  ATTENDANCE: {
    MARK: "/api/v1/attendance/mark",
    LOCK_SESSION: "/api/v1/attendance/lock-session",
  },
  FINANCE: {
    PAYMENT_REQUESTS: "/api/v1/finance/payment-requests",
    SEPAY_TRANSACTIONS: "/api/v1/finance/sepay-transactions",
    SPLIT_TRANSACTION: "/api/v1/finance/split-transaction",
  },
  CRM: {
    LEADS: "/api/v1/crm/leads",
    BOOK_TRIAL: "/api/v1/crm/trial-booking",
  },
  HR: {
    STAFF_LIST: "/api/v1/hr/staff",
    TIMEKEEPING: "/api/v1/hr/timekeeping",
    PAYROLL: "/api/v1/hr/payroll",
  }
};
